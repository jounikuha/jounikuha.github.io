An assessment of the causes of the errors in the 2015 UK General Election opinion polls
by Sturgis, P., Kuha, J., Baker, N., Callegaro, M., Fisher, S., Green, J., Jennings, W.,
Lauderdale, B. E., and Smith, P., Journal of the Royal Statistical Society A, 2017.   

[** add contact details **]

Data and code for a synthetic example to illustrate the methods of polling estimation and
bootstrap estimation of standard errors which are described in the paper.

For more information about this example, please see a separate document [** link? **] in supplementary materials for the paper.

The following two files are included here: 

* PollingExample.R: An R script for carrying out the analysis. Extracts and output from it are included in this note.
It sources the contents of the next file.

* PollingExampleDataAndFunctions.R: Data (PollData) and three functions (poll.estimation, poll.bootstrap,
and quota.resample) used in the example.
Use the source function to load this file into R.

